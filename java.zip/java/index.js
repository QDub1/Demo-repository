
//Declaration Only


//Initialiazation only


/Delaration & Initialization/

//variable
//console.log(num1  num2 )



// let num1 = 32;
// let num2 = 12;

//let num3 = num1 < 5 && num2 >=10
// //num1 <= num2ojkojkoom       

// // console.log(num1  num2 )


// let num1 = 6
// let num2 = "45"
// // let num3 = parseInt(num1)
// num3 = num1 + num2 


// console.log( num3)


//javascript arrays
// //syntax for array

// var array_name = ["ayo", 007, true]
// console.log( array_name)


// var bridge_Class = new Array();
// bridge_Class[0] = "ireoluwa";
// bridge_Class[1] = "olaoluwa";
// bridge_Class[2] = false;


// bridge_Class.unshift("bello")

// console.log(bridge_Class)


// const bridge_Class_order =["Dorcas", "Ola", "Haroun"]

// document.getElementById('initial').innerHTML = bridge_Class_order

// bridge_Class_order.push("kafayat")
// bridge_Class_order.push("courage")
// bridge_Class_order
// const sizes = ["small","medium","large",]


// const cars =[
//     "Bmw",
//     "Volvo",
//     "toyota",
//    " ferrari"
// ]
// console.log(cars[cars.length-1])

// let cars_string = cars.join()
// console.log(cars_string)

// let alpha = "ola david tunde kelvin"
// let $aplha = alpha.split (" ")
// console.log ($aplha)

// let males = ["Courage","micheal","ola", "Ebenezer", "tomiwa"]

// let females = ["kafayat", "dorcas", "fedeelah",]



 //Array

// const Bridge_Class_students = [
//     "mike",
//     "dayo",
//     "doyin",
//     "seun",
//     "mikun"
// ]

// const Bridge_Class_students2 = {
//     student1: "mike",
//     student2: "dayo",
//     student3: "doyin",
//     student4: "seun",
//     student5: "mikun"
// }
// console.log(Bridge_Class_students2)


// const Bridge_Class_students3 = new Object()
// Bridge_Class_students3.student6 ="mike",
// Bridge_Class_students3.student7 ="dayo",
// Bridge_Class_students3.student8 = "doyin",
// Bridge_Class_students3.student9 = "seun",
// Bridge_Class_students3.student10 ="mikun"

// console.log(Bridge_Class_students3)

// const Bridge_Class_students4=Object.create(Bridge_Class_students3)
// Bridge_Class_students4.student11 =  "seun",
// Bridge_Class_students4.student12 = ["aske","ololade",["olamide","saheed",["wizkid"],"seyi",] "idan"],

// console.log(Bridge_Class_students4)

// console.log(Bridge_Class_students4.student12[2])





// //Array inside Array
// const football =[
//     { club: ['man u',"Aresenal" "man city", "barca"]},
//     { forwards: ['hallad',"ronaldo" "saka","messi"]},
    
// ]

// console.log(football.[club])


// //Object in Object
// const football ={
//     league:{
//         premier_league:{
//             Man_City:{
//                 player:{
//                     forwards:["Grealish","Haaland", "Alvarez"],
//                     midfielders:["kdb", "Rodri","Gundogan"],
//                     defenders:["Ake","Akanji","Walker" ]
//                 }
//             },
//             Aresenal:{
//                 player:{
//                     forwards:["Saka","jesus","NKetia"],
//                     midfielders:["jorginho","Odegga","Parte"],
//                     defenders:["Saliba","white","holding"]
//                 }
//             },
//             Newcastle:{
//                 player:{
//                     forwards:["Isak","Ameron","Maxima"],
//                     midfielders:["Murphy","","Parte"],
//                     defenders:["Saliba","white","holding"]
//                 }
//             },
//             Man_United:{},
//             Liverpool:{}
//         },
//         seria_A:{

//         },
//         LaLiga:{

//         },
//         Bundesliga:{

//         },
//     }
// }

// console.log(foodball.league.premier_league )

const bridge_class = {
    batchA:{
        male:["samuel","tomiwa","Haroun","ayomide","lekan"],

        female:["yetunde","kafayat","karimot","olwadamilola","aisha"]
    },

    batchB:{
        male:["remi","micheal","ibrahim","ire","ore"],

        Female:["Fadeela","modinat","kudi","basirat","iyanuoula"]
    }
}

console.log(bridge_class.batchA.female);
console.log(bridge_class.batchB.male)









